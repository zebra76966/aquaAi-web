import "./ContactSection.css";
import { useState } from "react";
import { FiMail, FiMessageCircle, FiPhone, FiGlobe, FiSend, FiInstagram, FiTwitter, FiFacebook, FiYoutube } from "react-icons/fi";

export default function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const update = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <section className="contact-section" id="contact">
      <div className="contact-inner">
        <div className="contact-heading">
          <p className="contact-eyebrow">Contact Us</p>
          <h2 className="contact-title">
            Get in <span className="contact-accent">Touch</span>
          </h2>
          <p className="contact-subtitle">We're here to help. Reach out through any channel that suits you.</p>
        </div>

        <div className="contact-grid">
          {/* Form */}
          <div className="contact-form-wrap">
            <div className="contact-form">
              <div className="cf-row">
                <div className="cf-field">
                  <label className="cf-label">Your Name</label>
                  <input className="cf-input" type="text" placeholder="Jane Smith" value={form.name} onChange={update("name")} />
                </div>
                <div className="cf-field">
                  <label className="cf-label">Email Address</label>
                  <input className="cf-input" type="email" placeholder="jane@example.com" value={form.email} onChange={update("email")} />
                </div>
              </div>
              <div className="cf-field">
                <label className="cf-label">Subject</label>
                <input className="cf-input" type="text" placeholder="How can we help?" value={form.subject} onChange={update("subject")} />
              </div>
              <div className="cf-field">
                <label className="cf-label">Message</label>
                <textarea className="cf-input cf-textarea" rows={5} placeholder="Tell us what's on your mind..." value={form.message} onChange={update("message")} />
              </div>
              <button className="cf-submit">
                <FiSend /> Send Message
              </button>
            </div>
          </div>

          {/* Contact info card */}
          <div className="contact-info-card">
            <h3 className="ci-heading">Contact Details</h3>
            <div className="ci-items">
              <div className="ci-item">
                <div className="ci-icon">
                  <FiMail />
                </div>
                <div>
                  <p className="ci-label">Support</p>
                  <a href="mailto:support@aquaai.uk" className="ci-value">
                    support@aquaai.uk
                  </a>
                </div>
              </div>

              <div className="ci-item">
                <div className="ci-icon">
                  <FiMail />
                </div>
                <div>
                  <p className="ci-label">For Providers</p>
                  <a href="mailto:providers@aquaai.uk" className="ci-value">
                    providers@aquaai.uk
                  </a>
                </div>
              </div>

              <div className="ci-item">
                <div className="ci-icon">
                  <FiMessageCircle />
                </div>
                <div>
                  <p className="ci-label">WhatsApp</p>
                  <a href="https://wa.me/447586576323" className="ci-value">
                    +44 7586 576323
                  </a>
                </div>
              </div>
              <div className="ci-item">
                <div className="ci-icon">
                  <FiPhone />
                </div>
                <div>
                  <p className="ci-label">SMS</p>
                  <a href="sms:+447782207333" className="ci-value">
                    +44 7782 207333
                  </a>
                </div>
              </div>
              <div className="ci-item">
                <div className="ci-icon">
                  <FiGlobe />
                </div>
                <div>
                  <p className="ci-label">Website</p>
                  <a href="https://www.aquaai.uk" target="_blank" rel="noreferrer" className="ci-value">
                    www.aquaai.uk
                  </a>
                </div>
              </div>
            </div>

            <div className="ci-socials-wrap">
              <p className="ci-label">Follow Us</p>
              <div className="ci-socials">
                {[FiInstagram, FiTwitter, FiFacebook, FiYoutube].map((Icon, i) => (
                  <a key={i} href="#" className="ci-social">
                    <Icon />
                  </a>
                ))}
              </div>
            </div>

            <div className="ci-note">
              <p>
                Operated by <strong>Humara Ltd</strong>
              </p>
              <p>Registered in England and Wales</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
