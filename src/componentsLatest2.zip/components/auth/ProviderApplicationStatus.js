/**
 * ProviderApplicationStatus.js
 * Shown to any user with is_for_provider=true after login.
 * Shows live consultant + breeder application statuses fetched from the API.
 * Mirrors the React Native ApplicationStatusScreen but as a web component.
 */
import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Spinner } from "react-bootstrap";
import {
  FiCheckCircle, FiClock, FiXCircle, FiHelpCircle,
  FiBriefcase, FiAlertCircle, FiLogOut, FiArrowRight,
  FiExternalLink
} from "react-icons/fi";
import { IoFishSharp } from "react-icons/io5";
import { AuthContext } from "./authcontext";
import { baseUrl } from "./config";
import "./ProviderApplicationStatus.css";

/* ── Deep-link back to the provider mobile app ── */
const PROVIDER_APP_SCHEME = "aquaproviders://";

/* ── Status metadata ── */
function statusMeta(status) {
  switch (status) {
    case "approved":  return { icon: FiCheckCircle, color: "#00d4ff", label: "Approved" };
    case "pending":   return { icon: FiClock,       color: "#f0a500", label: "Under Review" };
    case "rejected":  return { icon: FiXCircle,     color: "#ff4d4d", label: "Not Approved" };
    default:          return { icon: FiHelpCircle,  color: "#7a9ab0", label: "Not Applied" };
  }
}

/* ── Single application status card ── */
function StatusCard({ type, status, message }) {
  const meta = statusMeta(status);
  const Icon = meta.icon;

  return (
    <motion.div
      className={`pas-status-card pas-status-card--${status || "none"}`}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="pas-status-icon-wrap" style={{ color: meta.color }}>
        <Icon size={28} />
      </div>
      <div className="pas-status-info">
        <p className="pas-status-type">{type}</p>
        <p className="pas-status-label" style={{ color: meta.color }}>{meta.label}</p>
        {message && <p className="pas-status-msg">{message}</p>}
      </div>
    </motion.div>
  );
}

/* ── Role choice card ── */
function RoleCard({ icon: Icon, title, desc, onClick, disabled }) {
  return (
    <motion.button
      className={`pas-role-card${disabled ? " disabled" : ""}`}
      onClick={disabled ? undefined : onClick}
      whileHover={disabled ? {} : { y: -3, scale: 1.01 }}
      whileTap={disabled ? {} : { scale: 0.98 }}
    >
      <div className="pas-role-icon"><Icon size={26} /></div>
      <h3 className="pas-role-title">{title}</h3>
      <p className="pas-role-desc">{desc}</p>
      {!disabled && <FiArrowRight className="pas-role-arrow" />}
    </motion.button>
  );
}

export default function ProviderApplicationStatus() {
  const { token, logout }  = useContext(AuthContext);
  const navigate           = useNavigate();

  const [loading,           setLoading]           = useState(true);
  const [error,             setError]             = useState("");
  const [consultantStatus,  setConsultantStatus]  = useState(null);
  const [breederStatus,     setBreederStatus]     = useState(null);
  const [consultantMsg,     setConsultantMsg]     = useState("");
  const [breederMsg,        setBreederMsg]        = useState("");

  /* Fetch both statuses in parallel */
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const [cRes, bRes] = await Promise.all([
          fetch(`${baseUrl}/consultants/application/status/`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch(`${baseUrl}/breeders/application/status/`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (cRes.status === 401 || bRes.status === 401) {
          logout();
          navigate("/login");
          return;
        }

        const cJson = await cRes.json().catch(() => null);
        const bJson = await bRes.json().catch(() => null);

        const cStatus = cRes.ok
          ? (cJson?.data?.status?.admin_status ?? cJson?.data?.status?.application_status ?? "not_applied")
          : "not_applied";
        const bStatus = bRes.ok
          ? (bJson?.data?.status?.admin_status ?? bJson?.data?.status?.application_status ?? "not_applied")
          : "not_applied";

        setConsultantStatus(cStatus);
        setBreederStatus(bStatus);
        setConsultantMsg(cJson?.data?.message || "");
        setBreederMsg(bJson?.data?.message  || "");
      } catch {
        setError("Could not load application status. Please try again.");
      } finally {
        setLoading(false);
      }
    })();
  }, [token]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const openProviderApp = () => {
    window.location.href = PROVIDER_APP_SCHEME;
  };

  const goToLogin = () => {
    /* Log out first so they can log back in to get the refreshed role */
    logout();
    navigate("/login");
  };

  /* ── Derived states ── */
  const noneApplied     = consultantStatus === "not_applied" && breederStatus === "not_applied";
  const bothApproved    = consultantStatus === "approved"    && breederStatus === "approved";
  const showCStatus     = consultantStatus && consultantStatus !== "not_applied";
  const showBStatus     = breederStatus    && breederStatus   !== "not_applied";
  const canApplyConsult = consultantStatus === "not_applied";
  const canApplyBreeder = breederStatus    === "not_applied";

  if (loading) {
    return (
      <div className="pas-page">
        <div className="pas-bg"><div className="pas-orb pas-orb-a" /><div className="pas-orb pas-orb-b" /></div>
        <div className="pas-loader"><Spinner animation="border" style={{ color: "#00d4ff" }} /></div>
      </div>
    );
  }

  return (
    <div className="pas-page">
      {/* Background */}
      <div className="pas-bg">
        <div className="pas-orb pas-orb-a" />
        <div className="pas-orb pas-orb-b" />
        <div className="pas-grid" />
      </div>

      {/* Top bar */}
      <div className="pas-topbar">
        <div className="pas-logo">
          <img src="/favicon32.png" alt="AquaAI" className="pas-logo-img" />
          <span>AquaAI</span>
        </div>
        <button className="pas-logout-btn" onClick={handleLogout}>
          <FiLogOut size={15} /> Sign out
        </button>
      </div>

      <div className="pas-center">
        <motion.div
          className="pas-card"
          initial={{ opacity: 0, y: 32, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >

          {/* ── Error ── */}
          {error && (
            <div className="pas-alert pas-alert--error">
              <FiAlertCircle /> <span>{error}</span>
            </div>
          )}

          {/* ══════════════════════════════════════
              CASE 1: Neither applied yet → choose role
              ══════════════════════════════════════ */}
          {noneApplied && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap"><IoFishSharp size={28} /></div>
                <h1 className="pas-title">Choose Your Path</h1>
                <p className="pas-subtitle">How would you like to join Aqua AI as a provider?</p>
              </div>
              <div className="pas-roles">
                <RoleCard
                  icon={FiBriefcase}
                  title="Apply as Consultant"
                  desc="Offer aquatic services, manage bookings, and grow your professional business."
                  onClick={() => navigate("/consultant")}
                />
                <RoleCard
                  icon={IoFishSharp}
                  title="Apply as Breeder"
                  desc="List your stock, manage enquiries, and build your breeder brand."
                  onClick={() => navigate("/breeder")}
                />
              </div>
            </>
          )}

          {/* ══════════════════════════════════════
              CASE 2: One or both applied/pending/rejected → show statuses
              ══════════════════════════════════════ */}
          {!noneApplied && !bothApproved && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap"><FiClock size={28} /></div>
                <h1 className="pas-title">Application Status</h1>
                <p className="pas-subtitle">Here's where things stand with your applications.</p>
              </div>

              {/* Status cards */}
              <div className="pas-statuses">
                {showCStatus && (
                  <StatusCard type="Consultant" status={consultantStatus} message={consultantMsg} />
                )}
                {showBStatus && (
                  <StatusCard type="Breeder" status={breederStatus} message={breederMsg} />
                )}
              </div>

              {/* Can still apply for the other role */}
              {(canApplyConsult || canApplyBreeder) && (
                <div className="pas-also-apply">
                  <p className="pas-also-label">Also interested in…</p>
                  <div className="pas-roles pas-roles--compact">
                    {canApplyConsult && (
                      <RoleCard
                        icon={FiBriefcase}
                        title="Apply as Consultant"
                        desc="Offer services, manage bookings."
                        onClick={() => navigate("/consultant")}
                      />
                    )}
                    {canApplyBreeder && (
                      <RoleCard
                        icon={IoFishSharp}
                        title="Apply as Breeder"
                        desc="List stock, manage enquiries."
                        onClick={() => navigate("/breeder")}
                      />
                    )}
                  </div>
                </div>
              )}

              {/* Return to app options */}
              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Return to Aqua Providers App
                </button>
                <button className="pas-return-btn pas-return-btn--ghost" onClick={goToLogin}>
                  Continue to Web Dashboard
                </button>
              </div>
            </>
          )}

          {/* ══════════════════════════════════════
              CASE 3: Both approved → return options
              ══════════════════════════════════════ */}
          {bothApproved && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap pas-icon-wrap--success"><FiCheckCircle size={28} /></div>
                <h1 className="pas-title">You're Approved!</h1>
                <p className="pas-subtitle">Both your applications have been approved. Where would you like to go?</p>
              </div>

              <div className="pas-statuses">
                <StatusCard type="Consultant" status="approved" message={consultantMsg} />
                <StatusCard type="Breeder"    status="approved" message={breederMsg} />
              </div>

              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Open Aqua Providers App
                </button>
                <button className="pas-return-btn pas-return-btn--ghost" onClick={goToLogin}>
                  Continue to Web Dashboard
                </button>
              </div>
            </>
          )}

        </motion.div>
      </div>
    </div>
  );
}
