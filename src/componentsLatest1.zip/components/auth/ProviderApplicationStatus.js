/**
 * ProviderApplicationStatus.js
 * Shown after login when is_for_provider === true, and after submitting
 * a breeder/consultant application.
 *
 * Logic:
 *  - Neither applied      → Choose Your Path (apply as breeder / consultant)
 *  - One/both pending     → Show status cards + "also apply" + return buttons
 *  - One approved         → Show status + "Go to [Role] Dashboard" as primary CTA
 *  - Both approved        → Show both statuses + choose which dashboard to enter
 */
import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Spinner } from "react-bootstrap";
import {
  FiCheckCircle, FiClock, FiXCircle, FiHelpCircle,
  FiBriefcase, FiAlertCircle, FiLogOut, FiArrowRight,
  FiExternalLink, FiGrid,
} from "react-icons/fi";
import { IoFishSharp } from "react-icons/io5";
import { AuthContext } from "./authcontext";
import { baseUrl } from "./config";
import "./ProviderApplicationStatus.css";

const PROVIDER_APP_SCHEME = "aquaproviders://";

/* ── Status metadata ── */
function statusMeta(status) {
  switch (status) {
    case "approved": return { icon: FiCheckCircle, color: "#00d4ff",  label: "Approved" };
    case "pending":  return { icon: FiClock,       color: "#f0a500",  label: "Under Review" };
    case "rejected": return { icon: FiXCircle,     color: "#ff4d4d",  label: "Not Approved" };
    default:         return { icon: FiHelpCircle,  color: "#7a9ab0",  label: "Not Applied" };
  }
}

/* ── Status card ── */
function StatusCard({ type, status, message }) {
  const meta = statusMeta(status);
  const Icon = meta.icon;
  return (
    <motion.div
      className={`pas-status-card pas-status-card--${status || "none"}`}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="pas-status-icon-wrap" style={{ color: meta.color }}>
        <Icon size={28} />
      </div>
      <div className="pas-status-info">
        <p className="pas-status-type">{type}</p>
        <p className="pas-status-label" style={{ color: meta.color }}>{meta.label}</p>
        {message && <p className="pas-status-msg">{message}</p>}
      </div>
    </motion.div>
  );
}

/* ── Role choice / apply card ── */
function RoleCard({ icon: Icon, title, desc, onClick }) {
  return (
    <motion.button
      className="pas-role-card"
      onClick={onClick}
      whileHover={{ y: -3, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="pas-role-icon"><Icon size={26} /></div>
      <h3 className="pas-role-title">{title}</h3>
      <p className="pas-role-desc">{desc}</p>
      <FiArrowRight className="pas-role-arrow" />
    </motion.button>
  );
}

export default function ProviderApplicationStatus() {
  const { token, logout, login } = useContext(AuthContext);
  const navigate                 = useNavigate();

  const [loading,          setLoading]          = useState(true);
  const [error,            setError]            = useState("");
  const [consultantStatus, setConsultantStatus] = useState(null);
  const [breederStatus,    setBreederStatus]    = useState(null);
  const [consultantMsg,    setConsultantMsg]    = useState("");
  const [breederMsg,       setBreederMsg]       = useState("");

  /* Fetch both application statuses in parallel */
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const [cRes, bRes] = await Promise.all([
          fetch(`${baseUrl}/consultants/application/status/`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
          fetch(`${baseUrl}/breeders/application/status/`, {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        if (cRes.status === 401 || bRes.status === 401) {
          logout();
          navigate("/login");
          return;
        }

        const cJson = await cRes.json().catch(() => null);
        const bJson = await bRes.json().catch(() => null);

        const cStatus = cRes.ok
          ? (cJson?.data?.status?.admin_status ?? cJson?.data?.status?.application_status ?? "not_applied")
          : "not_applied";
        const bStatus = bRes.ok
          ? (bJson?.data?.status?.admin_status ?? bJson?.data?.status?.application_status ?? "not_applied")
          : "not_applied";

        setConsultantStatus(cStatus);
        setBreederStatus(bStatus);
        setConsultantMsg(cJson?.data?.message || "");
        setBreederMsg(bJson?.data?.message   || "");
      } catch {
        setError("Could not load application status. Please try again.");
      } finally {
        setLoading(false);
      }
    })();
  }, [token]);

  /* Navigate to a dashboard — update roles in context first */
  const goToDashboard = (role) => {
    /* Update the stored role so FloatingNav + routing work correctly */
    const currentRoles = JSON.parse(localStorage.getItem("userRoles") || "[]");
    if (!currentRoles.includes(role)) {
      const updated = [...currentRoles, role];
      localStorage.setItem("userRoles", JSON.stringify(updated));
    }
    navigate(role === "breeder" ? "/breeder-dashboard" : "/consultant-dashboard");
  };

  const handleLogout    = () => { logout(); navigate("/login"); };
  const openProviderApp = () => { window.location.href = PROVIDER_APP_SCHEME; };

  /* ── Derived booleans ── */
  const noneApplied        = consultantStatus === "not_applied" && breederStatus === "not_applied";
  const consultantApproved = consultantStatus === "approved";
  const breederApproved    = breederStatus    === "approved";
  const bothApproved       = consultantApproved && breederApproved;
  const onlyConsultant     = consultantApproved && !breederApproved;
  const onlyBreeder        = breederApproved    && !consultantApproved;
  const hasAnyApproval     = consultantApproved || breederApproved;
  const showCStatus        = consultantStatus && consultantStatus !== "not_applied";
  const showBStatus        = breederStatus    && breederStatus    !== "not_applied";
  const canApplyConsult    = consultantStatus === "not_applied";
  const canApplyBreeder    = breederStatus    === "not_applied";
  /* "pending only" — applied but nothing approved yet */
  const pendingOnly        = !noneApplied && !hasAnyApproval;

  if (loading) {
    return (
      <div className="pas-page">
        <div className="pas-bg"><div className="pas-orb pas-orb-a" /><div className="pas-orb pas-orb-b" /></div>
        <div className="pas-loader"><Spinner animation="border" style={{ color: "#00d4ff" }} /></div>
      </div>
    );
  }

  return (
    <div className="pas-page">
      <div className="pas-bg">
        <div className="pas-orb pas-orb-a" />
        <div className="pas-orb pas-orb-b" />
        <div className="pas-grid" />
      </div>

      {/* Top bar */}
      <div className="pas-topbar">
        <div className="pas-logo">
          <img src="/favicon32.png" alt="AquaAI" className="pas-logo-img" />
          <span>AquaAI</span>
        </div>
        <button className="pas-logout-btn" onClick={handleLogout}>
          <FiLogOut size={15} /> Sign out
        </button>
      </div>

      <div className="pas-center">
        <motion.div
          className="pas-card"
          initial={{ opacity: 0, y: 32, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          {error && (
            <div className="pas-alert pas-alert--error">
              <FiAlertCircle /> <span>{error}</span>
            </div>
          )}

          {/* ══════════════════════════════════════════
              CASE 1 — Neither applied: choose a path
              ══════════════════════════════════════════ */}
          {noneApplied && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap"><IoFishSharp size={28} /></div>
                <h1 className="pas-title">Choose Your Path</h1>
                <p className="pas-subtitle">How would you like to join Aqua AI as a provider?</p>
              </div>
              <div className="pas-roles">
                <RoleCard
                  icon={FiBriefcase}
                  title="Apply as Consultant"
                  desc="Offer aquatic services, manage bookings, and grow your professional business."
                  onClick={() => navigate("/consultant")}
                />
                <RoleCard
                  icon={IoFishSharp}
                  title="Apply as Breeder"
                  desc="List your stock, manage enquiries, and build your breeder brand."
                  onClick={() => navigate("/breeder")}
                />
              </div>
            </>
          )}

          {/* ══════════════════════════════════════════
              CASE 2 — Applied but nothing approved yet
              ══════════════════════════════════════════ */}
          {pendingOnly && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap"><FiClock size={28} /></div>
                <h1 className="pas-title">Application Status</h1>
                <p className="pas-subtitle">Here's where things stand with your applications.</p>
              </div>

              <div className="pas-statuses">
                {showCStatus && <StatusCard type="Consultant" status={consultantStatus} message={consultantMsg} />}
                {showBStatus && <StatusCard type="Breeder"    status={breederStatus}    message={breederMsg} />}
              </div>

              {/* Apply for the other role if not yet applied */}
              {(canApplyConsult || canApplyBreeder) && (
                <div className="pas-also-apply">
                  <p className="pas-also-label">Also interested in…</p>
                  <div className="pas-roles pas-roles--compact">
                    {canApplyConsult && (
                      <RoleCard icon={FiBriefcase} title="Apply as Consultant" desc="Offer services, manage bookings." onClick={() => navigate("/consultant")} />
                    )}
                    {canApplyBreeder && (
                      <RoleCard icon={IoFishSharp} title="Apply as Breeder" desc="List stock, manage enquiries." onClick={() => navigate("/breeder")} />
                    )}
                  </div>
                </div>
              )}

              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Return to Aqua Providers App
                </button>
              </div>
            </>
          )}

          {/* ══════════════════════════════════════════
              CASE 3 — Only Consultant approved
              ══════════════════════════════════════════ */}
          {onlyConsultant && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap pas-icon-wrap--success"><FiCheckCircle size={28} /></div>
                <h1 className="pas-title">Consultant Approved!</h1>
                <p className="pas-subtitle">Your consultant application has been approved. Ready to get started?</p>
              </div>

              <div className="pas-statuses">
                <StatusCard type="Consultant" status="approved"       message={consultantMsg} />
                {showBStatus && <StatusCard type="Breeder" status={breederStatus} message={breederMsg} />}
              </div>

              {/* Apply as breeder too if not yet applied */}
              {canApplyBreeder && (
                <div className="pas-also-apply">
                  <p className="pas-also-label">Also interested in…</p>
                  <div className="pas-roles pas-roles--compact">
                    <RoleCard icon={IoFishSharp} title="Apply as Breeder" desc="List stock, manage enquiries." onClick={() => navigate("/breeder")} />
                  </div>
                </div>
              )}

              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={() => goToDashboard("consultant")}>
                  <FiGrid size={15} /> Go to Consultant Dashboard
                </button>
                <button className="pas-return-btn pas-return-btn--ghost" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Return to Aqua Providers App
                </button>
              </div>
            </>
          )}

          {/* ══════════════════════════════════════════
              CASE 4 — Only Breeder approved
              ══════════════════════════════════════════ */}
          {onlyBreeder && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap pas-icon-wrap--success"><FiCheckCircle size={28} /></div>
                <h1 className="pas-title">Breeder Approved!</h1>
                <p className="pas-subtitle">Your breeder application has been approved. Ready to get started?</p>
              </div>

              <div className="pas-statuses">
                {showCStatus && <StatusCard type="Consultant" status={consultantStatus} message={consultantMsg} />}
                <StatusCard type="Breeder" status="approved" message={breederMsg} />
              </div>

              {/* Apply as consultant too if not yet applied */}
              {canApplyConsult && (
                <div className="pas-also-apply">
                  <p className="pas-also-label">Also interested in…</p>
                  <div className="pas-roles pas-roles--compact">
                    <RoleCard icon={FiBriefcase} title="Apply as Consultant" desc="Offer services, manage bookings." onClick={() => navigate("/consultant")} />
                  </div>
                </div>
              )}

              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={() => goToDashboard("breeder")}>
                  <FiGrid size={15} /> Go to Breeder Dashboard
                </button>
                <button className="pas-return-btn pas-return-btn--ghost" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Return to Aqua Providers App
                </button>
              </div>
            </>
          )}

          {/* ══════════════════════════════════════════
              CASE 5 — Both approved: pick which dashboard
              ══════════════════════════════════════════ */}
          {bothApproved && (
            <>
              <div className="pas-header">
                <div className="pas-icon-wrap pas-icon-wrap--success"><FiCheckCircle size={28} /></div>
                <h1 className="pas-title">Both Approved!</h1>
                <p className="pas-subtitle">Both applications are approved. Which dashboard would you like to open?</p>
              </div>

              <div className="pas-statuses">
                <StatusCard type="Consultant" status="approved" message={consultantMsg} />
                <StatusCard type="Breeder"    status="approved" message={breederMsg} />
              </div>

              <div className="pas-return">
                <button className="pas-return-btn pas-return-btn--primary" onClick={() => goToDashboard("consultant")}>
                  <FiBriefcase size={15} /> Go to Consultant Dashboard
                </button>
                <button className="pas-return-btn pas-return-btn--primary pas-return-btn--teal" onClick={() => goToDashboard("breeder")}>
                  <IoFishSharp size={15} /> Go to Breeder Dashboard
                </button>
                <button className="pas-return-btn pas-return-btn--ghost" onClick={openProviderApp}>
                  <FiExternalLink size={15} /> Return to Aqua Providers App
                </button>
              </div>
            </>
          )}

        </motion.div>
      </div>
    </div>
  );
}
