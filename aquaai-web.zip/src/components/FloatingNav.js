import React, { useContext, useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AuthContext } from "./auth/authcontext";
import "./FloatingNav.css";

const USER_ITEMS = [
  { path: "/dashboard", label: "Dashboard", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>) },
  { path: "/tanks", label: "Tanks", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 12h20M2 12c0-5 4-9 10-9s10 4 10 9M2 12c0 5 4 9 10 9s10-4 10-9"/><path d="M6 16c1-1 2-1.5 3-1s2 1 3 1 2-.5 3-1 2-1 3-1"/></svg>) },
  { path: "/profile", label: "Profile", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>) },
];

const BREEDER_ITEMS = [
  { path: "/breeder-dashboard", label: "Hub", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>) },
  { path: "/breeder-dashboard", label: "Species", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 8c0 4-6 9-6 9s-6-5-6-9a6 6 0 0 1 12 0z"/></svg>), tab: "species" },
  { path: "/breeder-dashboard", label: "Analytics", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>), tab: "analytics" },
  { path: "/breeder-dashboard", label: "Profile", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>), tab: "profile" },
];

const CONSULTANT_ITEMS = [
  { path: "/consultant-dashboard", label: "Dashboard", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/></svg>) },
  { path: "/consultant-dashboard", label: "Calendar", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>), tab: "calendar" },
  { path: "/consultant-dashboard", label: "Analytics", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>), tab: "analytics" },
  { path: "/consultant-dashboard", label: "Profile", icon: (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>), tab: "profile" },
];

export default function FloatingNav() {
  const { token, roles, isAdmin } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [visible, setVisible] = useState(false);

  const isBreeder = roles.includes("breeder");
  const isConsultant = roles.includes("consultant");
  const isRegularUser = token && !isAdmin && !isBreeder && !isConsultant;

  const AUTH_ROUTES = ["/login", "/register", "/forgot-password", "/plans", "/payment/success", "/payment/fail"];
  const shouldHide = AUTH_ROUTES.includes(location.pathname) || isAdmin || !token;

  useEffect(() => {
    if (!shouldHide) setTimeout(() => setVisible(true), 300);
    else setVisible(false);
  }, [shouldHide]);

  if (shouldHide) return null;

  const items = isBreeder ? BREEDER_ITEMS : isConsultant ? CONSULTANT_ITEMS : USER_ITEMS;

  return (
    <nav className={`floating-nav ${visible ? "nav-visible" : ""}`}>
      <div className="nav-pill">
        {items.map((item, i) => {
          const isActive = location.pathname === item.path;
          return (
            <button
              key={i}
              className={`nav-item ${isActive ? "nav-active" : ""}`}
              onClick={() => navigate(item.path)}
              aria-label={item.label}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {isActive && <span className="nav-dot" />}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
