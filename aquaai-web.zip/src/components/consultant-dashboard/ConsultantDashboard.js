import React, { useEffect, useState, useContext, useCallback } from "react";
import { AuthContext } from "../auth/authcontext";
import { baseUrl } from "../auth/config";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaBriefcase, FaCalendarAlt, FaChartBar, FaUser,
  FaCheckCircle, FaHourglassHalf, FaClock, FaStar,
  FaDollarSign, FaExclamationTriangle, FaShieldAlt,
  FaBrain, FaLightbulb, FaArrowUp, FaArrowDown,
  FaTrophy, FaToggleOn, FaToggleOff,
  FaGlobe, FaInstagram, FaFacebook, FaSave,
  FaBuilding, FaChevronRight, FaSync,
} from "react-icons/fa";
import { MdBusiness } from "react-icons/md";
import "./ConsultantDashboard.css";

const Spinner = () => <div className="cd-spinner" />;
const KpiCard = ({ label, value, icon, color, trend }) => (
  <div className="cd-kpi" style={{ "--kc": color }}>
    <span className="cd-kpi-icon" style={{ color }}>{icon}</span>
    <span className="cd-kpi-val">{value ?? "—"}</span>
    <span className="cd-kpi-label">{label}</span>
    {trend != null && (
      <span className={"cd-kpi-trend " + (trend >= 0 ? "cd-trend--up" : "cd-trend--down")}>
        {trend >= 0 ? <FaArrowUp /> : <FaArrowDown />} {Math.abs(trend)}%
      </span>
    )}
  </div>
);
const InsightRow = ({ text }) => (
  <div className="cd-insight-row"><FaLightbulb className="cd-insight-icon" /><p>{text}</p></div>
);
const SectionHead = ({ icon, title }) => (
  <div className="cd-section-head"><span className="cd-section-icon">{icon}</span><h3 className="cd-section-title">{title}</h3></div>
);

// ═══════════════════════════════════════════════
//  TAB: DASHBOARD
// ═══════════════════════════════════════════════
function DashboardTab({ token }) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${baseUrl}/intelligence/dashboard/consultant/`, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      });
      const json = await res.json();
      if (!res.ok) { setError(json.message || "Failed to load"); return; }
      setData(json);
    } catch (e) { setError("Something went wrong"); } finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchDashboard(); }, [fetchDashboard]);

  if (loading) return <div className="cd-loading"><Spinner /><p>Loading dashboard…</p></div>;
  if (error) return (
    <div className="cd-loading">
      <FaExclamationTriangle style={{ color: "#f87171", fontSize: 32 }} />
      <p style={{ color: "#f87171" }}>{error}</p>
      <button className="cd-retry-btn" onClick={fetchDashboard}><FaSync /> Retry</button>
    </div>
  );

  const kpi = data?.kpi;
  const trends = data?.trends;
  const disputeRisk = data?.disputeRisk;
  const cohort = data?.cohortBenchmark;
  const aiInsights = data?.aiInsights || [];
  const bookingStatus = data?.bookingStatus;

  return (
    <div>
      {kpi && (
        <div className="cd-kpi-grid">
          <KpiCard label="Total Bookings" value={kpi.totalBookings} icon={<FaCalendarAlt />} color="#00f2ff" trend={trends?.bookingsChange} />
          <KpiCard label="Earnings" value={kpi.totalEarnings != null ? `$${kpi.totalEarnings}` : "—"} icon={<FaDollarSign />} color="#4ade80" trend={trends?.earningsChange} />
          <KpiCard label="Avg Rating" value={kpi.avgRating || "—"} icon={<FaStar />} color="#fbbf24" />
          <KpiCard label="Completion" value={kpi.completionRate != null ? kpi.completionRate + "%" : "—"} icon={<FaCheckCircle />} color="#a78bfa" />
          <KpiCard label="Pending" value={kpi.pendingBookings ?? "—"} icon={<FaHourglassHalf />} color="#f472b6" />
          <KpiCard label="Avg Response" value={kpi.avgResponseHours != null ? kpi.avgResponseHours + "h" : "—"} icon={<FaClock />} color="#60a5fa" />
        </div>
      )}

      {/* Booking pipeline */}
      {bookingStatus && (
        <div className="cd-card">
          <SectionHead icon={<FaBriefcase />} title="Booking Pipeline" />
          <div className="cd-status-grid">
            {Object.entries(bookingStatus).map(([k, v]) => (
              <div key={k} className="cd-status-pill">
                <span className="cd-status-val">{v}</span>
                <span className="cd-status-key">{k}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Dispute risk */}
      {disputeRisk && (
        <div className={"cd-card cd-risk-card " + (disputeRisk.risk_level === "low" ? "cd-risk--low" : "cd-risk--high")}>
          <div className="cd-risk-header">
            {disputeRisk.risk_level === "low" ? <FaCheckCircle /> : <FaExclamationTriangle />}
            <span>Dispute Risk — {disputeRisk.risk_level?.toUpperCase()}</span>
            {disputeRisk.dispute_probability != null && (
              <span className="cd-risk-pct">{(disputeRisk.dispute_probability * 100).toFixed(0)}%</span>
            )}
          </div>
          <p className="cd-risk-msg">{disputeRisk.intervention_message}</p>
        </div>
      )}

      {/* Cohort */}
      {cohort && (
        <div className="cd-card">
          <SectionHead icon={<FaTrophy />} title={`Cohort — ${cohort.tier || ""}`} />
          <p className="cd-narrative">{cohort.narrative}</p>
        </div>
      )}

      {/* AI Insights */}
      {aiInsights.length > 0 && (
        <div className="cd-ai-card">
          <div className="cd-ai-header"><FaBrain /><span>AI Performance Insights</span></div>
          {aiInsights.map((ins, i) => <InsightRow key={i} text={ins} />)}
        </div>
      )}

      {!kpi && (
        <div className="cd-empty-state">
          <FaChartBar />
          <p>Dashboard data not available yet. Complete your first booking to see insights.</p>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: CALENDAR + BOOKINGS
// ═══════════════════════════════════════════════
function CalendarTab({ token }) {
  const [calMode, setCalMode] = useState("calendar"); // "calendar" | "bookings"
  const [calLoading, setCalLoading] = useState(true);
  const [rawDays, setRawDays] = useState([]);
  const [sections, setSections] = useState([]);
  const [filter, setFilter] = useState("all");
  const [bookingsTab, setBookingsTab] = useState("pending");
  const [bookings, setBookings] = useState([]);
  const [bookLoading, setBookLoading] = useState(false);

  const fetchCalendar = useCallback(async () => {
    setCalLoading(true);
    try {
      const res = await fetch(`${baseUrl}/consultants/calendar/`, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      });
      const json = await res.json();
      const days = json.data?.calendar || [];
      setRawDays(days);
      applyFilter(days, "all");
    } catch (e) { console.error(e); } finally { setCalLoading(false); }
  }, [token]);

  const applyFilter = (days, f) => {
    setFilter(f);
    let d = days;
    if (f === "today") d = days.filter((x) => x.is_today);
    else if (f === "week") {
      const now = new Date(), end = new Date(); end.setDate(now.getDate() + 7);
      d = days.filter((x) => { const c = new Date(x.date); return c >= now && c <= end; });
    } else if (f === "booked") d = days.filter((x) => x.bookings?.length > 0);
    setSections(d.map((day) => ({ title: `${day.day_of_week}, ${day.date}`, isToday: day.is_today, bookings: day.bookings || [] })));
  };

  const fetchBookings = useCallback(async () => {
    setBookLoading(true);
    try {
      const res = await fetch(`${baseUrl}/consultants/consultant/bookings?status=${bookingsTab}`, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      });
      const json = await res.json();
      setBookings(json.data || []);
    } catch (e) { console.error(e); } finally { setBookLoading(false); }
  }, [token, bookingsTab]);

  const updateBookingStatus = async (id, status) => {
    try {
      await fetch(`${baseUrl}/consultants/bookings/${id}/update-status/`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      fetchBookings();
    } catch (e) { console.error(e); }
  };

  useEffect(() => { fetchCalendar(); }, [fetchCalendar]);
  useEffect(() => { if (calMode === "bookings") fetchBookings(); }, [calMode, fetchBookings]);

  const fmt = (iso) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const fmtDate = (iso) => new Date(iso).toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" });

  return (
    <div>
      <div className="cd-toggle-row">
        <button className={"cd-toggle-btn " + (calMode === "calendar" ? "cd-toggle-btn--active" : "")} onClick={() => setCalMode("calendar")}>
          <FaCalendarAlt /> Calendar
        </button>
        <button className={"cd-toggle-btn " + (calMode === "bookings" ? "cd-toggle-btn--active" : "")} onClick={() => setCalMode("bookings")}>
          <FaBriefcase /> Bookings
        </button>
      </div>

      <AnimatePresence mode="wait">
        {calMode === "calendar" && (
          <motion.div key="cal" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {/* Filters */}
            <div className="cd-filter-row">
              {["all", "today", "week", "booked"].map((f) => (
                <button key={f} className={"cd-filter-chip " + (filter === f ? "cd-filter-chip--active" : "")} onClick={() => applyFilter(rawDays, f)}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            {calLoading ? <div className="cd-loading"><Spinner /></div> : sections.length === 0 ? (
              <div className="cd-empty-state"><FaCalendarAlt /><p>No availability days found for this filter.</p></div>
            ) : (
              <div className="cd-cal-list">
                {sections.map((sec, i) => (
                  <div key={i} className={"cd-cal-day " + (sec.isToday ? "cd-cal-day--today" : "")}>
                    <div className="cd-cal-day-head">
                      <span className="cd-cal-day-label">{sec.title}</span>
                      {sec.isToday && <span className="cd-today-badge">Today</span>}
                      <span className="cd-cal-count">{sec.bookings.length} booking{sec.bookings.length !== 1 ? "s" : ""}</span>
                    </div>
                    {sec.bookings.length === 0 ? (
                      <p className="cd-cal-empty">Available — no bookings</p>
                    ) : (
                      <div className="cd-cal-bookings">
                        {sec.bookings.map((b, j) => (
                          <div key={j} className="cd-cal-booking-item">
                            <div className="cd-cal-booking-time">
                              <FaClock style={{ fontSize: 11, opacity: .5 }} />
                              {b.scheduled_start ? fmt(b.scheduled_start) : "—"}
                              {b.scheduled_end ? " – " + fmt(b.scheduled_end) : ""}
                            </div>
                            <div className="cd-cal-booking-info">
                              <span className="cd-cal-booking-name">{b.client_name || b.user_name || "Client"}</span>
                              {b.service_name && <span className="cd-cal-booking-service">{b.service_name}</span>}
                            </div>
                            <span className={"cd-booking-status-chip cd-status-" + (b.status || "pending")}>{b.status || "pending"}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {calMode === "bookings" && (
          <motion.div key="bk" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div className="cd-filter-row">
              {["pending", "active", "completed"].map((t) => (
                <button key={t} className={"cd-filter-chip " + (bookingsTab === t ? "cd-filter-chip--active" : "")} onClick={() => setBookingsTab(t)}>
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
            {bookLoading ? <div className="cd-loading"><Spinner /></div> : bookings.length === 0 ? (
              <div className="cd-empty-state"><FaBriefcase /><p>No {bookingsTab} bookings.</p></div>
            ) : (
              <div className="cd-bookings-list">
                {bookings.map((b, i) => (
                  <motion.div key={b.id || i} className="cd-booking-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                    <div className="cd-booking-top">
                      <div>
                        <p className="cd-booking-client">{b.client_name || b.user_name || "Client"}</p>
                        {b.service_name && <p className="cd-booking-service">{b.service_name}</p>}
                      </div>
                      <span className={"cd-booking-status-chip cd-status-" + (b.status || "pending")}>{b.status || "pending"}</span>
                    </div>
                    <div className="cd-booking-meta">
                      {b.scheduled_start && (
                        <span><FaCalendarAlt style={{ opacity: .5, fontSize: 11 }} /> {fmtDate(b.scheduled_start)}</span>
                      )}
                      {b.price != null && <span><FaDollarSign style={{ opacity: .5, fontSize: 11 }} /> {b.price}</span>}
                      {b.duration_minutes && <span><FaClock style={{ opacity: .5, fontSize: 11 }} /> {b.duration_minutes}m</span>}
                    </div>
                    {b.notes && <p className="cd-booking-notes">{b.notes}</p>}
                    {b.status === "pending" && (
                      <div className="cd-booking-actions">
                        <button className="cd-btn-accept" onClick={() => updateBookingStatus(b.id, "active")}>Accept</button>
                        <button className="cd-btn-decline" onClick={() => updateBookingStatus(b.id, "cancelled")}>Decline</button>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: ANALYTICS
// ═══════════════════════════════════════════════
function AnalyticsTab({ token }) {
  const [mode, setMode] = useState("analytics");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState(null);
  const [intel, setIntel] = useState(null);
  const [intelLoading, setIntelLoading] = useState(false);

  const fetchBase = useCallback(async () => {
    setLoading(true);
    try {
      const h = { Authorization: `Bearer ${token}` };
      const profRes = await fetch(`${baseUrl}/consultants/profile/`, { headers: h });
      const profJson = await profRes.json();
      const uid = profJson?.data?.id;
      setUserId(uid);
      const anaRes = await fetch(`${baseUrl}/intelligence/dashboard/consultant/?entity_type=consultant&entity_id=${uid}`, { headers: h });
      const anaJson = await anaRes.json();
      setData(anaJson);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  }, [token]);

  const fetchIntelligence = useCallback(async (uid) => {
    if (!uid) return;
    setIntelLoading(true);
    const h = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
    const fw = async (url, method = "GET", body = null) => {
      try { const opts = { method, headers: h }; if (body) opts.body = JSON.stringify(body); return await (await fetch(url, opts)).json(); } catch { return null; }
    };
    const [score, trajectory, digest, cohort, churn, disputeForecast] = await Promise.all([
      fw(`${baseUrl}/intelligence/trust/consultant/${uid}/score`),
      fw(`${baseUrl}/intelligence/trust/consultant/${uid}/trajectory`),
      fw(`${baseUrl}/intelligence/digest/consultant/${uid}/latest`),
      fw(`${baseUrl}/intelligence/cohort/consultant/${uid}`),
      fw(`${baseUrl}/intelligence/predict/churn/consultant/${uid}`),
      fw(`${baseUrl}/intelligence/dispute/predict`, "POST", { entity_id: uid, entity_type: "consultant" }),
    ]);
    setIntel({ score, trajectory, digest, cohort, churn, disputeForecast });
    setIntelLoading(false);
  }, [token]);

  useEffect(() => { fetchBase(); }, [fetchBase]);
  useEffect(() => { if (mode === "intelligence" && userId && !intel) fetchIntelligence(userId); }, [mode, userId, intel, fetchIntelligence]);

  if (loading) return <div className="cd-loading"><Spinner /></div>;

  const kpi = data?.kpi;
  const trends = data?.trends;
  const aiInsights = data?.aiInsights || [];
  const cohort = data?.cohortBenchmark;
  const bookingStatus = data?.bookingStatus;

  return (
    <div>
      <div className="cd-toggle-row">
        <button className={"cd-toggle-btn " + (mode === "analytics" ? "cd-toggle-btn--active" : "")} onClick={() => setMode("analytics")}><FaChartBar /> Analytics</button>
        <button className={"cd-toggle-btn " + (mode === "intelligence" ? "cd-toggle-btn--active" : "")} onClick={() => setMode("intelligence")}><FaBrain /> AI Intelligence</button>
      </div>
      <AnimatePresence mode="wait">
        {mode === "analytics" && (
          <motion.div key="ana" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {!data ? <div className="cd-empty-state"><FaChartBar /><p>No analytics data yet.</p></div> : (
              <>
                {kpi && (
                  <div className="cd-kpi-grid">
                    <KpiCard label="Total Bookings" value={kpi.totalBookings} icon={<FaCalendarAlt />} color="#00f2ff" trend={trends?.bookingsChange} />
                    <KpiCard label="Earnings" value={kpi.totalEarnings != null ? `$${kpi.totalEarnings}` : "—"} icon={<FaDollarSign />} color="#4ade80" trend={trends?.earningsChange} />
                    <KpiCard label="Avg Rating" value={kpi.avgRating || "—"} icon={<FaStar />} color="#fbbf24" />
                    <KpiCard label="Completion %" value={kpi.completionRate != null ? kpi.completionRate + "%" : "—"} icon={<FaCheckCircle />} color="#a78bfa" />
                  </div>
                )}
                {bookingStatus && (
                  <div className="cd-card">
                    <SectionHead icon={<FaBriefcase />} title="Booking Pipeline" />
                    <div className="cd-status-grid">
                      {Object.entries(bookingStatus).map(([k, v]) => (
                        <div key={k} className="cd-status-pill"><span className="cd-status-val">{v}</span><span className="cd-status-key">{k}</span></div>
                      ))}
                    </div>
                  </div>
                )}
                {cohort && <div className="cd-card"><SectionHead icon={<FaTrophy />} title={`Cohort — ${cohort.tier || ""}`} /><p className="cd-narrative">{cohort.narrative}</p></div>}
                {aiInsights.length > 0 && (
                  <div className="cd-ai-card">
                    <div className="cd-ai-header"><FaBrain /><span>AI Performance Insights</span></div>
                    {aiInsights.map((ins, i) => <InsightRow key={i} text={ins} />)}
                  </div>
                )}
              </>
            )}
          </motion.div>
        )}
        {mode === "intelligence" && (
          <motion.div key="intel" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {intelLoading ? <div className="cd-loading"><Spinner /><p>Loading AI Intelligence…</p></div> : !intel ? (
              <div className="cd-empty-state"><FaBrain /><p>AI intelligence not available yet.</p></div>
            ) : (
              <>
                {intel.score?.data && (
                  <div className="cd-card">
                    <SectionHead icon={<FaShieldAlt />} title="Trust Score" />
                    <div className="cd-trust-row">
                      <div className="cd-trust-circle">
                        <span className="cd-trust-num">{intel.score.data.trust_score ?? "—"}</span>
                        <span className="cd-trust-sub">Trust pts</span>
                      </div>
                      {intel.score.data.regulatory_tier && <p className="cd-trust-tier">{intel.score.data.tier_icon} {intel.score.data.regulatory_tier} Tier</p>}
                    </div>
                  </div>
                )}
                {intel.digest?.data && (
                  <div className="cd-ai-card">
                    <div className="cd-ai-header"><FaBrain /><span>Latest Intelligence Digest</span></div>
                    {intel.digest.data.insights?.map((ins, i) => <InsightRow key={i} text={ins} />) ||
                      <p className="cd-narrative">{intel.digest.data.summary || "No digest available."}</p>}
                  </div>
                )}
                {intel.churn?.data && (
                  <div className={"cd-card cd-risk-card " + (intel.churn.data.churn_risk === "low" ? "cd-risk--low" : "cd-risk--high")}>
                    <div className="cd-risk-header">
                      {intel.churn.data.churn_risk === "low" ? <FaCheckCircle /> : <FaExclamationTriangle />}
                      <span>Churn Risk — {intel.churn.data.churn_risk?.toUpperCase()}</span>
                    </div>
                    <p className="cd-risk-msg">{intel.churn.data.recommendation || intel.churn.data.message}</p>
                  </div>
                )}
                {intel.disputeForecast?.data && (
                  <div className={"cd-card cd-risk-card " + (intel.disputeForecast.data.risk_level === "low" ? "cd-risk--low" : "cd-risk--high")}>
                    <div className="cd-risk-header"><FaExclamationTriangle /><span>Dispute Risk Forecast</span></div>
                    <p className="cd-risk-msg">{intel.disputeForecast.data.intervention_message}</p>
                  </div>
                )}
                {(!intel.score && !intel.digest && !intel.churn) && (
                  <div className="cd-empty-state"><FaBrain /><p>AI intelligence endpoints returned no data. Activity needed.</p></div>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: PROFILE
// ═══════════════════════════════════════════════
function ProfileTab({ token }) {
  const [profileMode, setProfileMode] = useState("personal");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const [firstName, setFirstName] = useState(""); const [lastName, setLastName] = useState(""); const [email, setEmail] = useState("");
  const [loadingPersonal, setLoadingPersonal] = useState(true);

  const [companyName, setCompanyName] = useState(""); const [bio, setBio] = useState(""); const [website, setWebsite] = useState("");
  const [instagram, setInstagram] = useState(""); const [facebook, setFacebook] = useState("");
  const [policy, setPolicy] = useState(""); const [autoAccept, setAutoAccept] = useState(true); const [isEdit, setIsEdit] = useState(false);
  const [loadingBusiness, setLoadingBusiness] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${baseUrl}/user/profile/`, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json(); const d = json?.data || json;
        const p = (d.name || "").trim().split(" ");
        setFirstName(p[0] || ""); setLastName(p.slice(1).join(" ") || ""); setEmail(d.email || "");
      } catch (e) { console.error(e); } finally { setLoadingPersonal(false); }
    })();
    (async () => {
      try {
        const res = await fetch(`${baseUrl}/consultants/profile/`, { headers: { Authorization: `Bearer ${token}` } });
        const json = await res.json(); const d = json?.data || json;
        if (d?.company_name) {
          setIsEdit(true); setCompanyName(d.company_name || ""); setBio(d.bio || "");
          setWebsite(d.website || ""); setInstagram(d.instagram || ""); setFacebook(d.facebook || "");
          setPolicy(d.cancellation_policy || ""); setAutoAccept(!!d.auto_accept);
        }
      } catch (e) { console.error(e); } finally { setLoadingBusiness(false); }
    })();
  }, [token]);

  const savePersonal = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const fd = new FormData(); fd.append("first_name", firstName); fd.append("last_name", lastName);
      await fetch(`${baseUrl}/user/profile/update/`, { method: "PUT", headers: { Authorization: `Bearer ${token}` }, body: fd });
      setSuccess(true); setTimeout(() => setSuccess(false), 2500);
    } catch (e) { console.error(e); } finally { setSaving(false); }
  };

  const saveBusiness = async (e) => {
    e.preventDefault(); if (!companyName.trim()) return; setSaving(true);
    try {
      const url = isEdit ? `${baseUrl}/consultants/profile/update/` : `${baseUrl}/consultants/apply/`;
      await fetch(url, {
        method: isEdit ? "PUT" : "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ company_name: companyName, bio, website, instagram, facebook, cancellation_policy: policy, auto_accept: autoAccept }),
      });
      setSuccess(true); setTimeout(() => setSuccess(false), 2500);
    } catch (e) { console.error(e); } finally { setSaving(false); }
  };

  return (
    <div>
      <div className="cd-toggle-row">
        <button className={"cd-toggle-btn " + (profileMode === "personal" ? "cd-toggle-btn--active" : "")} onClick={() => setProfileMode("personal")}><FaUser /> Personal</button>
        <button className={"cd-toggle-btn " + (profileMode === "business" ? "cd-toggle-btn--active" : "")} onClick={() => setProfileMode("business")}><MdBusiness /> Business</button>
      </div>
      <AnimatePresence mode="wait">
        {profileMode === "personal" && (
          <motion.div key="per" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {loadingPersonal ? <div className="cd-loading"><Spinner /></div> : (
              <form onSubmit={savePersonal} className="cd-form">
                <div className="cd-form-grid">
                  <div className="cd-field"><label>First Name</label><input value={firstName} onChange={(e) => setFirstName(e.target.value)} /></div>
                  <div className="cd-field"><label>Last Name</label><input value={lastName} onChange={(e) => setLastName(e.target.value)} /></div>
                </div>
                <div className="cd-field"><label>Email <span className="cd-hint-label">(read-only)</span></label><input value={email} readOnly className="cd-input-disabled" /></div>
                <button type="submit" className="cd-save-btn" disabled={saving}>
                  {saving ? <Spinner /> : success ? <><FaCheckCircle /> Saved!</> : <><FaSave /> Save Changes</>}
                </button>
              </form>
            )}
          </motion.div>
        )}
        {profileMode === "business" && (
          <motion.div key="biz" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {loadingBusiness ? <div className="cd-loading"><Spinner /></div> : (
              <form onSubmit={saveBusiness} className="cd-form">
                <div className="cd-field"><label>Company Name *</label><input value={companyName} onChange={(e) => setCompanyName(e.target.value)} required /></div>
                <div className="cd-field"><label>Bio</label><textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} /></div>
                <div className="cd-form-grid">
                  <div className="cd-field"><label><FaGlobe /> Website</label><input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://" /></div>
                  <div className="cd-field"><label><FaInstagram /> Instagram</label><input value={instagram} onChange={(e) => setInstagram(e.target.value)} placeholder="@handle" /></div>
                  <div className="cd-field"><label><FaFacebook /> Facebook</label><input value={facebook} onChange={(e) => setFacebook(e.target.value)} /></div>
                </div>
                <div className="cd-field"><label>Cancellation Policy</label><textarea value={policy} onChange={(e) => setPolicy(e.target.value)} rows={2} /></div>
                <div className="cd-toggle-field">
                  <span>Auto-accept bookings</span>
                  <button type="button" className="cd-toggle-switch" onClick={() => setAutoAccept((v) => !v)}>
                    {autoAccept ? <FaToggleOn className="cd-toggle-on" /> : <FaToggleOff className="cd-toggle-off" />}
                  </button>
                </div>
                <button type="submit" className="cd-save-btn" disabled={saving}>
                  {saving ? <Spinner /> : success ? <><FaCheckCircle /> Saved!</> : <><FaSave /> {isEdit ? "Update Business" : "Create Profile"}</>}
                </button>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════
//  ROOT
// ═══════════════════════════════════════════════
const TABS = [
  { key: "dashboard", label: "Dashboard", icon: <FaBriefcase /> },
  { key: "calendar", label: "Calendar", icon: <FaCalendarAlt /> },
  { key: "analytics", label: "Analytics", icon: <FaChartBar /> },
  { key: "profile", label: "Profile", icon: <FaUser /> },
];

export default function ConsultantDashboard() {
  const { token } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="cd-wrapper">
      <div className="cd-bg" />
      <div className="cd-container">
        <motion.header className="cd-header" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
          <div>
            <p className="cd-eyebrow">AquaAI Consultant</p>
            <h1 className="cd-title">Intelligence Center</h1>
            <p className="cd-subtitle">Manage appointments, analytics, and your consulting business.</p>
          </div>
          <div className="cd-header-icon"><FaBriefcase /></div>
        </motion.header>

        <div className="cd-tabs">
          {TABS.map((t) => (
            <button key={t.key} className={"cd-tab " + (activeTab === t.key ? "cd-tab--active" : "")} onClick={() => setActiveTab(t.key)}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        <div className="cd-tab-content">
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && <motion.div key="d" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><DashboardTab token={token} /></motion.div>}
            {activeTab === "calendar" && <motion.div key="c" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><CalendarTab token={token} /></motion.div>}
            {activeTab === "analytics" && <motion.div key="a" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><AnalyticsTab token={token} /></motion.div>}
            {activeTab === "profile" && <motion.div key="p" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><ProfileTab token={token} /></motion.div>}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
