import React, { useEffect, useState, useContext, useCallback } from "react";
import { AuthContext } from "../auth/authcontext";
import { baseUrl } from "../auth/config";
import { motion, AnimatePresence } from "framer-motion";
import {
  FaFish, FaChartBar, FaBrain, FaUser, FaBuilding,
  FaClock, FaHeart, FaSkull, FaStar, FaShieldAlt,
  FaLightbulb, FaArrowUp, FaArrowDown, FaTrophy,
  FaLeaf, FaExclamationTriangle, FaCheckCircle,
  FaBox, FaInbox, FaImage, FaGlobe, FaInstagram,
  FaFacebook, FaToggleOn, FaToggleOff, FaEdit, FaSave,
  FaPlus, FaTrash, FaSync,
} from "react-icons/fa";
import { MdBusiness, MdScience } from "react-icons/md";
import "./BreederDashboard.css";

// ─── Shared spinner ─────────────────────────────
const Spinner = () => <div className="bd-spinner" />;

// ─── KPI Card ───────────────────────────────────
const KpiCard = ({ label, value, icon, color, sub }) => (
  <div className="bd-kpi" style={{ "--kc": color }}>
    <span className="bd-kpi-icon" style={{ color }}>{icon}</span>
    <span className="bd-kpi-val">{value ?? "—"}</span>
    <span className="bd-kpi-label">{label}</span>
    {sub && <span className="bd-kpi-sub">{sub}</span>}
  </div>
);

// ─── AI Insight row ─────────────────────────────
const InsightRow = ({ text }) => (
  <div className="bd-insight-row">
    <FaLightbulb className="bd-insight-icon" />
    <p>{text}</p>
  </div>
);

// ─── Section header ──────────────────────────────
const SectionHead = ({ icon, title, action }) => (
  <div className="bd-section-head">
    <span className="bd-section-icon">{icon}</span>
    <h3 className="bd-section-title">{title}</h3>
    {action && <div className="bd-section-action">{action}</div>}
  </div>
);

// ═══════════════════════════════════════════════
//  TAB: DASHBOARD
// ═══════════════════════════════════════════════
function DashboardTab({ token }) {
  const [loading, setLoading] = useState(true);
  const [overview, setOverview] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [userId, setUserId] = useState(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const h = { Authorization: `Bearer ${token}` };
      const profileRes = await fetch(`${baseUrl}/breeders/profile/`, { headers: h });
      const profileJson = await profileRes.json();
      const uid = profileJson?.data?.id;
      setUserId(uid);

      const [inqRes, availRes, analyticsRes] = await Promise.all([
        fetch(`${baseUrl}/breeders/inquiries/?status=pending`, { headers: h }),
        fetch(`${baseUrl}/breeders/availability/`, { headers: h }),
        uid ? fetch(`${baseUrl}/intelligence/dashboard/breeder/?entity_type=breeder&entity_id=${uid}`, { headers: h }) : Promise.resolve(null),
      ]);

      const inqJson = await inqRes.json().catch(() => ({}));
      const availJson = await availRes.json().catch(() => ({}));
      const anaJson = analyticsRes ? await analyticsRes.json().catch(() => null) : null;

      const today = new Date().toISOString().split("T")[0];
      const blockedToday = (availJson?.data || []).some((s) => s.start_time?.startsWith(today));

      setOverview({
        pendingInquiries: (inqJson?.data || []).length,
        speciesCount: (profileJson?.data?.species || []).length,
        available: !blockedToday,
        profile: profileJson?.data,
      });
      setAnalytics(anaJson);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  if (loading) return <div className="bd-loading"><Spinner /><p>Loading hub…</p></div>;

  const kpi = analytics?.kpi;
  const aiInsights = analytics?.aiInsights || [];
  const stockStatus = analytics?.stockStatus;
  const cohort = analytics?.cohortBenchmark;
  const disputeRisk = analytics?.disputeRisk;
  const trends = analytics?.trends;

  return (
    <div>
      {/* Overview stat row */}
      <div className="bd-stat-row">
        <div className="bd-stat"><span className="bd-stat-val">{overview?.pendingInquiries ?? 0}</span><span className="bd-stat-label">Pending Inquiries</span></div>
        <div className="bd-stat"><span className="bd-stat-val">{overview?.speciesCount ?? 0}</span><span className="bd-stat-label">Species Listed</span></div>
        <div className={"bd-stat " + (overview?.available ? "bd-stat--ok" : "bd-stat--warn")}>
          <span className="bd-stat-val">{overview?.available ? "Open" : "Blocked"}</span>
          <span className="bd-stat-label">Today's Status</span>
        </div>
      </div>

      {/* KPIs from intelligence */}
      {kpi && (
        <>
          <SectionHead icon={<FaChartBar />} title="Performance" />
          <div className="bd-kpi-grid">
            <KpiCard label="Sales" value={kpi.totalSales} icon={<FaBox />} color="#00f2ff" />
            <KpiCard label="Stock Sold" value={kpi.totalStockSold} icon={<FaFish />} color="#34d399" />
            <KpiCard label="Species" value={kpi.speciesCount} icon={<FaLeaf />} color="#a78bfa" />
            <KpiCard label="Avg Rating" value={kpi.avgRating || "—"} icon={<FaStar />} color="#fbbf24" />
            <KpiCard label="Healthy %" value={kpi.healthyStockRate != null ? kpi.healthyStockRate + "%" : "—"} icon={<FaHeart />} color="#f472b6" />
            <KpiCard label="Mortality %" value={kpi.mortalityRate != null ? kpi.mortalityRate + "%" : "—"} icon={<FaSkull />} color="#f87171" />
            <KpiCard label="Response" value={kpi.avgResponseHours != null ? kpi.avgResponseHours + "h" : "—"} icon={<FaClock />} color="#60a5fa" />
            <KpiCard label="Trust Score" value={kpi.localTrustScore || "—"} icon={<FaShieldAlt />} color="#4ade80" />
          </div>

          {trends && (
            <div className="bd-trends-row">
              {trends.salesChange != null && (
                <div className={"bd-trend-chip " + (trends.salesChange >= 0 ? "bd-trend--up" : "bd-trend--down")}>
                  {trends.salesChange >= 0 ? <FaArrowUp /> : <FaArrowDown />} Sales {trends.salesChange >= 0 ? "+" : ""}{trends.salesChange}%
                </div>
              )}
              {trends.stockChange != null && (
                <div className={"bd-trend-chip " + (trends.stockChange >= 0 ? "bd-trend--up" : "bd-trend--down")}>
                  {trends.stockChange >= 0 ? <FaArrowUp /> : <FaArrowDown />} Stock {trends.stockChange >= 0 ? "+" : ""}{trends.stockChange}%
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Stock status */}
      {stockStatus && (
        <div className="bd-card">
          <SectionHead icon={<FaBox />} title="Inventory Status" />
          <div className="bd-status-grid">
            {Object.entries(stockStatus).map(([k, v]) => (
              <div key={k} className="bd-status-pill">
                <span className="bd-status-val">{v}</span>
                <span className="bd-status-key">{k.replace(/([A-Z])/g, " $1")}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cohort */}
      {cohort && (
        <div className="bd-card">
          <SectionHead icon={<FaTrophy />} title={`Tier Comparison — ${cohort.tier || ""}`} />
          <p className="bd-narrative">{cohort.narrative}</p>
          {cohort.metrics && (
            <div className="bd-benchmark-row">
              {cohort.metrics.avg_review_rating && (
                <div className="bd-benchmark-stat">
                  <span className="bd-b-val">{cohort.metrics.avg_review_rating.percentile}th</span>
                  <span className="bd-b-label">Review Percentile</span>
                </div>
              )}
              {cohort.metrics.inquiry_response_rate && (
                <div className="bd-benchmark-stat">
                  <span className="bd-b-val">{cohort.metrics.inquiry_response_rate.percentile}th</span>
                  <span className="bd-b-label">Inquiry Percentile</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Dispute risk */}
      {disputeRisk && (
        <div className={"bd-card bd-risk-card " + (disputeRisk.risk_level === "low" ? "bd-risk--low" : "bd-risk--high")}>
          <div className="bd-risk-header">
            {disputeRisk.risk_level === "low" ? <FaCheckCircle /> : <FaExclamationTriangle />}
            <span>Dispute Risk — {disputeRisk.risk_level?.toUpperCase()}</span>
            <span className="bd-risk-pct">{disputeRisk.dispute_probability != null ? (disputeRisk.dispute_probability * 100).toFixed(0) + "%" : ""}</span>
          </div>
          <p className="bd-risk-msg">{disputeRisk.intervention_message}</p>
        </div>
      )}

      {/* AI Insights (Analytics toggle shows Trust Intelligence) */}
      {aiInsights.length > 0 && (
        <div className="bd-ai-card">
          <div className="bd-ai-header"><FaBrain /><span>AI Insights</span></div>
          {aiInsights.map((ins, i) => <InsightRow key={i} text={ins} />)}
        </div>
      )}

      {!kpi && !loading && (
        <div className="bd-empty-state">
          <FaChartBar />
          <p>Intelligence data not available yet — check back after your first activity.</p>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: SPECIES MANAGEMENT
// ═══════════════════════════════════════════════
function SpeciesTab({ token }) {
  const [species, setSpecies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState(null);

  const fetchSpecies = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${baseUrl}/breeders/profile/`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      setSpecies(json?.data?.species || []);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  }, [token]);

  useEffect(() => { fetchSpecies(); }, [fetchSpecies]);

  const handleDelete = async (id) => {
    if (!window.confirm("Remove this species listing?")) return;
    setDeletingId(id);
    try {
      await fetch(`${baseUrl}/breeders/species/${id}/delete/`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      setSpecies((p) => p.filter((s) => s.id !== id));
    } catch (e) { console.error(e); } finally { setDeletingId(null); }
  };

  if (loading) return <div className="bd-loading"><Spinner /></div>;

  return (
    <div>
      <div className="bd-section-head-row">
        <SectionHead icon={<FaFish />} title={`Species (${species.length})`} />
        <p className="bd-hint">Manage via the mobile app to add species with AI scan.</p>
      </div>
      {species.length === 0 ? (
        <div className="bd-empty-state"><FaFish /><p>No species listed yet. Use the AquaAI mobile app to add species via AI scan.</p></div>
      ) : (
        <div className="bd-species-list">
          {species.map((s, i) => (
            <motion.div key={s.id || i} className="bd-species-card" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
              {s.image_url ? <img src={s.image_url} alt={s.name} className="bd-species-img" /> : <div className="bd-species-img-ph"><FaFish /></div>}
              <div className="bd-species-info">
                <p className="bd-species-name">{s.name || s.species_name || "Unknown"}</p>
                <p className="bd-species-sci">{s.scientific_name || s.scientific || ""}</p>
                <div className="bd-species-chips">
                  {s.price != null && <span className="bd-chip bd-chip--green">£{s.price}</span>}
                  {s.quantity != null && <span className="bd-chip">Qty: {s.quantity}</span>}
                  {s.available != null && <span className={"bd-chip " + (s.available ? "bd-chip--ok" : "bd-chip--warn")}>{s.available ? "Available" : "Sold Out"}</span>}
                </div>
              </div>
              <button className="bd-species-del" onClick={() => handleDelete(s.id)} disabled={deletingId === s.id} aria-label="Remove">
                {deletingId === s.id ? <Spinner /> : <FaTrash />}
              </button>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: ANALYTICS (standard + AI intelligence toggle)
// ═══════════════════════════════════════════════
function AnalyticsTab({ token }) {
  const [mode, setMode] = useState("analytics"); // "analytics" | "intelligence"
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [intel, setIntel] = useState(null);
  const [userId, setUserId] = useState(null);
  const [intelLoading, setIntelLoading] = useState(false);

  const fetchBase = useCallback(async () => {
    setLoading(true);
    try {
      const h = { Authorization: `Bearer ${token}` };
      const profRes = await fetch(`${baseUrl}/breeders/profile/`, { headers: h });
      const profJson = await profRes.json();
      const uid = profJson?.data?.id;
      setUserId(uid);
      if (uid) {
        const anaRes = await fetch(`${baseUrl}/intelligence/dashboard/breeder/?entity_type=breeder&entity_id=${uid}`, { headers: h });
        const anaJson = await anaRes.json();
        setData(anaJson);
      }
    } catch (e) { console.error(e); } finally { setLoading(false); }
  }, [token]);

  const fetchIntelligence = useCallback(async (uid) => {
    if (!uid) return;
    setIntelLoading(true);
    const h = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
    const fw = async (url, method = "GET", body = null) => {
      try {
        const opts = { method, headers: h };
        if (body) opts.body = JSON.stringify(body);
        const r = await fetch(url, opts);
        return await r.json();
      } catch { return null; }
    };
    const [score, trajectory, digest, cohort, pricing, churn, risk] = await Promise.all([
      fw(`${baseUrl}/intelligence/trust/breeder/${uid}/score`),
      fw(`${baseUrl}/intelligence/trust/breeder/${uid}/trajectory`),
      fw(`${baseUrl}/intelligence/digest/breeder/${uid}/latest`),
      fw(`${baseUrl}/intelligence/cohort/breeder/${uid}`),
      fw(`${baseUrl}/intelligence/pricing/${uid}`),
      fw(`${baseUrl}/intelligence/predict/churn/breeder/${uid}`),
      fw(`${baseUrl}/intelligence/off-platform/risk-breakdown/breeder/${uid}`),
    ]);
    setIntel({ score, trajectory, digest, cohort, pricing, churn, risk });
    setIntelLoading(false);
  }, [token]);

  useEffect(() => { fetchBase(); }, [fetchBase]);
  useEffect(() => { if (mode === "intelligence" && userId && !intel) fetchIntelligence(userId); }, [mode, userId, intel, fetchIntelligence]);

  if (loading) return <div className="bd-loading"><Spinner /></div>;

  const kpi = data?.kpi;
  const aiInsights = data?.aiInsights || [];
  const stockStatus = data?.stockStatus;
  const cohortData = data?.cohortBenchmark;

  return (
    <div>
      {/* Toggle */}
      <div className="bd-toggle-row">
        <button className={"bd-toggle-btn " + (mode === "analytics" ? "bd-toggle-btn--active" : "")} onClick={() => setMode("analytics")}>
          <FaChartBar /> Analytics
        </button>
        <button className={"bd-toggle-btn " + (mode === "intelligence" ? "bd-toggle-btn--active" : "")} onClick={() => setMode("intelligence")}>
          <FaBrain /> AI Intelligence
        </button>
      </div>

      <AnimatePresence mode="wait">
        {mode === "analytics" && (
          <motion.div key="ana" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {!data ? (
              <div className="bd-empty-state"><FaChartBar /><p>No analytics data available yet.</p></div>
            ) : (
              <>
                {kpi && (
                  <div className="bd-kpi-grid">
                    <KpiCard label="Sales" value={kpi.totalSales} icon={<FaBox />} color="#00f2ff" />
                    <KpiCard label="Stock Sold" value={kpi.totalStockSold} icon={<FaFish />} color="#34d399" />
                    <KpiCard label="Species" value={kpi.speciesCount} icon={<FaLeaf />} color="#a78bfa" />
                    <KpiCard label="Avg Rating" value={kpi.avgRating || "—"} icon={<FaStar />} color="#fbbf24" />
                    <KpiCard label="Healthy %" value={kpi.healthyStockRate != null ? kpi.healthyStockRate + "%" : "—"} icon={<FaHeart />} color="#f472b6" />
                    <KpiCard label="Mortality %" value={kpi.mortalityRate != null ? kpi.mortalityRate + "%" : "—"} icon={<FaSkull />} color="#f87171" />
                    <KpiCard label="Response" value={kpi.avgResponseHours != null ? kpi.avgResponseHours + "h" : "—"} icon={<FaClock />} color="#60a5fa" />
                    <KpiCard label="Trust" value={kpi.localTrustScore || "—"} icon={<FaShieldAlt />} color="#4ade80" />
                  </div>
                )}
                {stockStatus && (
                  <div className="bd-card">
                    <SectionHead icon={<FaBox />} title="Inventory Status" />
                    <div className="bd-status-grid">
                      {Object.entries(stockStatus).map(([k, v]) => (
                        <div key={k} className="bd-status-pill">
                          <span className="bd-status-val">{v}</span>
                          <span className="bd-status-key">{k.replace(/([A-Z])/g, " $1")}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {cohortData && (
                  <div className="bd-card">
                    <SectionHead icon={<FaTrophy />} title={`Tier — ${cohortData.tier || ""}`} />
                    <p className="bd-narrative">{cohortData.narrative}</p>
                  </div>
                )}
                {aiInsights.length > 0 && (
                  <div className="bd-ai-card">
                    <div className="bd-ai-header"><FaBrain /><span>AI Insights</span></div>
                    {aiInsights.map((ins, i) => <InsightRow key={i} text={ins} />)}
                  </div>
                )}
              </>
            )}
          </motion.div>
        )}

        {mode === "intelligence" && (
          <motion.div key="intel" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {intelLoading ? (
              <div className="bd-loading"><Spinner /><p>Loading AI Intelligence…</p></div>
            ) : !intel ? (
              <div className="bd-empty-state"><FaBrain /><p>Intelligence data not available yet.</p></div>
            ) : (
              <>
                {/* Trust Score */}
                {intel.score?.data && (
                  <div className="bd-card">
                    <SectionHead icon={<FaShieldAlt />} title="Trust Score" />
                    <div className="bd-trust-row">
                      <div className="bd-trust-circle">
                        <span className="bd-trust-num">{intel.score.data.trust_score ?? "—"}</span>
                        <span className="bd-trust-sub">Trust Points</span>
                      </div>
                      <div>
                        {intel.score.data.regulatory_tier && <p className="bd-trust-tier">{intel.score.data.tier_icon} {intel.score.data.regulatory_tier} Tier</p>}
                      </div>
                    </div>
                  </div>
                )}
                {/* Digest */}
                {intel.digest?.data && (
                  <div className="bd-ai-card">
                    <div className="bd-ai-header"><FaBrain /><span>Latest Intelligence Digest</span></div>
                    {intel.digest.data.insights?.map((ins, i) => <InsightRow key={i} text={ins} />) ||
                      <p className="bd-narrative">{intel.digest.data.summary || "No digest available."}</p>}
                  </div>
                )}
                {/* Churn prediction */}
                {intel.churn?.data && (
                  <div className={"bd-card bd-risk-card " + (intel.churn.data.churn_risk === "low" ? "bd-risk--low" : "bd-risk--high")}>
                    <div className="bd-risk-header">
                      {intel.churn.data.churn_risk === "low" ? <FaCheckCircle /> : <FaExclamationTriangle />}
                      <span>Churn Risk — {intel.churn.data.churn_risk?.toUpperCase()}</span>
                    </div>
                    <p className="bd-risk-msg">{intel.churn.data.recommendation || intel.churn.data.message}</p>
                  </div>
                )}
                {/* Pricing */}
                {intel.pricing?.data && (
                  <div className="bd-card">
                    <SectionHead icon={<FaStar />} title="Pricing Intelligence" />
                    <p className="bd-narrative">{intel.pricing.data.recommendation || JSON.stringify(intel.pricing.data)}</p>
                  </div>
                )}
                {(!intel.score && !intel.digest && !intel.churn && !intel.pricing) && (
                  <div className="bd-empty-state"><FaBrain /><p>AI Intelligence endpoints returned no data yet. Activity needed to generate insights.</p></div>
                )}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════
//  TAB: PROFILE (personal + business)
// ═══════════════════════════════════════════════
function ProfileTab({ token }) {
  const [profileMode, setProfileMode] = useState("personal"); // "personal" | "business"
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  // Personal
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [loadingPersonal, setLoadingPersonal] = useState(true);

  // Business
  const [companyName, setCompanyName] = useState("");
  const [bio, setBio] = useState("");
  const [website, setWebsite] = useState("");
  const [instagram, setInstagram] = useState("");
  const [facebook, setFacebook] = useState("");
  const [policy, setPolicy] = useState("");
  const [autoAccept, setAutoAccept] = useState(true);
  const [isEdit, setIsEdit] = useState(false);
  const [loadingBusiness, setLoadingBusiness] = useState(true);

  const fetchPersonal = useCallback(async () => {
    try {
      const res = await fetch(`${baseUrl}/user/profile/`, { headers: { Authorization: `Bearer ${token}` } });
      const json = await res.json();
      const d = json?.data || json;
      const parts = (d.name || "").trim().split(" ");
      setFirstName(parts[0] || ""); setLastName(parts.slice(1).join(" ") || "");
      setEmail(d.email || "");
    } catch (e) { console.error(e); } finally { setLoadingPersonal(false); }
  }, [token]);

  const fetchBusiness = useCallback(async () => {
    try {
      const res = await fetch(`${baseUrl}/breeders/profile/`, { headers: { Authorization: `Bearer ${token}` } });
      const json = await res.json();
      const d = json?.data || json;
      if (d?.company_name) {
        setIsEdit(true); setCompanyName(d.company_name || ""); setBio(d.bio || "");
        setWebsite(d.website || ""); setInstagram(d.instagram || ""); setFacebook(d.facebook || "");
        setPolicy(d.cancellation_policy || ""); setAutoAccept(!!d.auto_accept);
      }
    } catch (e) { console.error(e); } finally { setLoadingBusiness(false); }
  }, [token]);

  useEffect(() => { fetchPersonal(); fetchBusiness(); }, [fetchPersonal, fetchBusiness]);

  const savePersonal = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const fd = new FormData();
      fd.append("first_name", firstName); fd.append("last_name", lastName);
      await fetch(`${baseUrl}/user/profile/update/`, { method: "PUT", headers: { Authorization: `Bearer ${token}` }, body: fd });
      setSuccess(true); setTimeout(() => setSuccess(false), 2500);
    } catch (err) { console.error(err); } finally { setSaving(false); }
  };

  const saveBusiness = async (e) => {
    e.preventDefault(); if (!companyName.trim()) return; setSaving(true);
    try {
      const url = isEdit ? `${baseUrl}/breeders/profile/update/` : `${baseUrl}/breeders/apply/`;
      await fetch(url, {
        method: isEdit ? "PUT" : "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ company_name: companyName, bio, website, instagram, facebook, cancellation_policy: policy, auto_accept: autoAccept }),
      });
      setSuccess(true); setTimeout(() => setSuccess(false), 2500);
    } catch (err) { console.error(err); } finally { setSaving(false); }
  };

  return (
    <div>
      <div className="bd-toggle-row">
        <button className={"bd-toggle-btn " + (profileMode === "personal" ? "bd-toggle-btn--active" : "")} onClick={() => setProfileMode("personal")}>
          <FaUser /> Personal
        </button>
        <button className={"bd-toggle-btn " + (profileMode === "business" ? "bd-toggle-btn--active" : "")} onClick={() => setProfileMode("business")}>
          <MdBusiness /> Business
        </button>
      </div>

      <AnimatePresence mode="wait">
        {profileMode === "personal" && (
          <motion.div key="personal" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {loadingPersonal ? <div className="bd-loading"><Spinner /></div> : (
              <form onSubmit={savePersonal} className="bd-form">
                <div className="bd-form-grid">
                  <div className="bd-field"><label>First Name</label><input value={firstName} onChange={(e) => setFirstName(e.target.value)} /></div>
                  <div className="bd-field"><label>Last Name</label><input value={lastName} onChange={(e) => setLastName(e.target.value)} /></div>
                </div>
                <div className="bd-field">
                  <label>Email <span className="bd-hint-label">(read-only)</span></label>
                  <input value={email} readOnly className="bd-input-disabled" />
                </div>
                <button type="submit" className="bd-save-btn" disabled={saving}>
                  {saving ? <Spinner /> : success ? <><FaCheckCircle /> Saved!</> : <><FaSave /> Save Changes</>}
                </button>
              </form>
            )}
          </motion.div>
        )}

        {profileMode === "business" && (
          <motion.div key="business" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            {loadingBusiness ? <div className="bd-loading"><Spinner /></div> : (
              <form onSubmit={saveBusiness} className="bd-form">
                <div className="bd-field"><label>Company Name *</label><input value={companyName} onChange={(e) => setCompanyName(e.target.value)} required /></div>
                <div className="bd-field"><label>Bio</label><textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} /></div>
                <div className="bd-form-grid">
                  <div className="bd-field"><label><FaGlobe /> Website</label><input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="https://" /></div>
                  <div className="bd-field"><label><FaInstagram /> Instagram</label><input value={instagram} onChange={(e) => setInstagram(e.target.value)} placeholder="@handle" /></div>
                  <div className="bd-field"><label><FaFacebook /> Facebook</label><input value={facebook} onChange={(e) => setFacebook(e.target.value)} /></div>
                </div>
                <div className="bd-field"><label>Cancellation Policy</label><textarea value={policy} onChange={(e) => setPolicy(e.target.value)} rows={2} /></div>
                <div className="bd-toggle-field">
                  <span>Auto-accept bookings</span>
                  <button type="button" className="bd-toggle-switch" onClick={() => setAutoAccept((v) => !v)}>
                    {autoAccept ? <FaToggleOn className="bd-toggle-on" /> : <FaToggleOff className="bd-toggle-off" />}
                  </button>
                </div>
                <button type="submit" className="bd-save-btn" disabled={saving}>
                  {saving ? <Spinner /> : success ? <><FaCheckCircle /> Saved!</> : <><FaSave /> {isEdit ? "Update Business" : "Create Profile"}</>}
                </button>
              </form>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════
//  ROOT: BREEDER DASHBOARD
// ═══════════════════════════════════════════════
const TABS = [
  { key: "dashboard", label: "Hub", icon: <FaFish /> },
  { key: "species", label: "Species", icon: <MdScience /> },
  { key: "analytics", label: "Analytics", icon: <FaChartBar /> },
  { key: "profile", label: "Profile", icon: <FaUser /> },
];

export default function BreederDashboard() {
  const { token, userProfile } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="bd-wrapper">
      <div className="bd-bg" />
      <div className="bd-container">
        {/* Header */}
        <motion.header className="bd-header" initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
          <div>
            <p className="bd-eyebrow">AquaAI Breeder</p>
            <h1 className="bd-title">Breeder Hub</h1>
            <p className="bd-subtitle">Manage your species, analytics, and business profile.</p>
          </div>
          <div className="bd-header-avatar">
            <FaFish />
          </div>
        </motion.header>

        {/* Tabs */}
        <div className="bd-tabs">
          {TABS.map((t) => (
            <button key={t.key} className={"bd-tab " + (activeTab === t.key ? "bd-tab--active" : "")} onClick={() => setActiveTab(t.key)}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="bd-tab-content">
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && <motion.div key="d" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><DashboardTab token={token} /></motion.div>}
            {activeTab === "species" && <motion.div key="s" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><SpeciesTab token={token} /></motion.div>}
            {activeTab === "analytics" && <motion.div key="a" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><AnalyticsTab token={token} /></motion.div>}
            {activeTab === "profile" && <motion.div key="p" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><ProfileTab token={token} /></motion.div>}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
